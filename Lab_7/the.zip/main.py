from functions import test_time, are_equal, ex_5, ex_8, ex_9

# Ex_2 = None
test_time()


# Ex_3 = None
print(are_equal("ex_1.py", "ex_1.py"))
print(are_equal("ex_7.py", "ex_1.py"))


# Ex_5 = None
ex_5("./", "py")


Ex_8 = None
print(ex_8("the.zip", "main.py"))


Ex_9 = None
print(ex_9("samples.zip"))
